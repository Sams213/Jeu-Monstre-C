var searchData=
[
  ['removeheadmonster_0',['removeHeadMonster',['../sae_8c.html#ab5cac974bd671bdbd06307b070ddbf5d',1,'removeHeadMonster(ListeMonstre l):&#160;sae.c'],['../sae_8h.html#ab5cac974bd671bdbd06307b070ddbf5d',1,'removeHeadMonster(ListeMonstre l):&#160;sae.c']]],
  ['removeheadplayer_1',['removeHeadPlayer',['../sae_8c.html#ac2eec70d204bba3578a2f27282c27dd0',1,'removeHeadPlayer(ListePlayer *l):&#160;sae.c'],['../sae_8h.html#ac2eec70d204bba3578a2f27282c27dd0',1,'removeHeadPlayer(ListePlayer *l):&#160;sae.c']]],
  ['resultatduel_2',['ResultatDuel',['../sae_8c.html#a23ba801fd273fb498b68ba1e9c30fca7',1,'ResultatDuel(Player *p, Monster *m):&#160;sae.c'],['../sae_8h.html#a23ba801fd273fb498b68ba1e9c30fca7',1,'ResultatDuel(Player *p, Monster *m):&#160;sae.c']]]
];
