var searchData=
[
  ['simulatetyping_0',['simulateTyping',['../sae_8c.html#a2361fc1188304d54493efff386a28749',1,'simulateTyping(char *str, int delay):&#160;sae.c'],['../sae_8h.html#ae4427105cfd88ff99cab3cebd305d45d',1,'simulateTyping(char *str, int speed):&#160;sae.c']]]
];
