var searchData=
[
  ['inserer_0',['inserer',['../sae_8c.html#a0fe216ded985637e739cdd2532152c6e',1,'inserer(Player *lp, Player *p):&#160;sae.c'],['../sae_8h.html#a0fe216ded985637e739cdd2532152c6e',1,'inserer(Player *lp, Player *p):&#160;sae.c']]]
];
