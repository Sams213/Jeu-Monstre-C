var searchData=
[
  ['player_0',['player',['../structplayer.html',1,'']]]
];
