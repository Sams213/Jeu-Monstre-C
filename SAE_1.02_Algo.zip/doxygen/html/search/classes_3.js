var searchData=
[
  ['score_0',['Score',['../struct_score.html',1,'']]]
];
